SPIN_TEXT = "🎰 Испытать удачу!"
START_POINTS = 50
STICKER_FAIL = "CAACAgIAAxkBAAEFGxpfqmqG-MltYIj4zjmFl1eCBfvhZwACuwIAAuPwEwwS3zJY4LIw9B4E"
THROTTLE_TIME_SPIN = 2  # время искусственной задержки между броском дайса и ответом, оно же период троттлинга
THROTTLE_TIME_OTHER = 1  # время искусственной задержки между остальными командами, оно же период троттлинга
